# RAG-Enhanced Brand Caption Generation System

A full-stack application that automatically generates brand-aligned social media captions from product images using RAG (Retrieval-Augmented Generation), BLIP-2, and GPT.

## 🏗️ Architecture

```
Brand Website + Social Media
            ↓
      Web Scraper / API
            ↓
      Brand Text Corpus
            ↓
   Chunking + Embeddings
            ↓
  Vector Database (ChromaDB)

User Uploads Image
            ↓
        BLIP-2
      (Image → Caption)
            ↓
   Caption used as Query
            ↓
  Retrieve Relevant Brand Data
            ↓
      LLM (GPT-3.5)
[Image Caption + Brand Info + Tone]
            ↓
   Final Instagram Caption
```

## 🚀 Tech Stack

### Backend
- **Flask** - REST API
- **BLIP** - Image captioning (Salesforce/blip-image-captioning-base)
- **ChromaDB** - Vector database for RAG
- **Sentence Transformers** - Text embeddings
- **Google Gemini** - Caption generation (FREE!)
- **BeautifulSoup** - Web scraping

### Frontend
- **React** - UI framework
- **Axios** - HTTP client
- **React Dropzone** - Image upload

## 📋 Prerequisites

- Python 3.8+
- Node.js 16+
- Google Gemini API Key (Already configured!)
- 4GB+ RAM (for BLIP model)

## 🔧 Installation & Setup

### 1. Clone/Navigate to Project

```bash
cd brand-caption-system
```

### 2. Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# The .env file is already configured with your Gemini API key
# If you need to change it, edit backend/.env
```

### 3. Frontend Setup

```bash
cd ../frontend

# Install dependencies
npm install
```

## ▶️ Running the Application

### Start Backend (Terminal 1)

```bash
cd backend
source venv/bin/activate  # On Windows: venv\Scripts\activate
python app.py
```

Backend will run on: `http://localhost:5000`

### Start Frontend (Terminal 2)

```bash
cd frontend
npm start
```

Frontend will run on: `http://localhost:3000`

## 📖 Usage Guide

### 1. Add a Brand

1. Click **"+ Add New Brand"** button
2. Enter brand details:
   - **Brand Name**: e.g., Nike, Apple
   - **Website URL**: Brand's official website
   - **Instagram Handle** (optional): @brandname
3. Click **"Add Brand"**
4. Wait for scraping to complete (~30 seconds)

### 2. Generate Caption

1. **Select Brand** from dropdown
2. **Choose Personality**:
   - Sincerity
   - Excitement
   - Competence
   - Sophistication
   - Ruggedness
3. **Upload Image**: Drag & drop or click to select
4. Click **"Generate Caption"**
5. Wait for generation (~10 seconds)
6. Copy the final caption with hashtags

## 🔑 API Endpoints

### Health Check
```
GET /api/health
```

### Get Brands
```
GET /api/brands
Response: {
  "success": true,
  "brands": ["Nike", "Apple", ...]
}
```

### Add Brand
```
POST /api/brands/add
Body: {
  "brand_name": "Nike",
  "website_url": "https://www.nike.com",
  "instagram_handle": "@nike"
}
```

### Generate Caption (from Image)
```
POST /api/caption/generate
Form Data:
  - image: file
  - brand_name: string
  - personality: string
```

### Generate Caption (from Text)
```
POST /api/caption/generate-text
Body: {
  "description": "black running shoe",
  "brand_name": "Nike",
  "personality": "excitement"
}
```

## 📁 Project Structure

```
brand-caption-system/
├── backend/
│   ├── app.py                      # Flask application
│   ├── requirements.txt            # Python dependencies
│   ├── .env.example               # Environment template
│   └── services/
│       ├── image_captioning.py    # BLIP-2 service
│       ├── rag_service.py         # ChromaDB RAG
│       ├── caption_generator.py   # GPT caption generation
│       └── brand_scraper.py       # Web scraping
│
└── frontend/
    ├── package.json               # Node dependencies
    ├── public/
    │   └── index.html
    └── src/
        ├── App.js                 # Main component
        ├── App.css
        ├── index.js
        └── components/
            ├── ImageUpload.js     # Image upload component
            ├── BrandSelector.js   # Brand selection
            ├── CaptionDisplay.js  # Results display
            └── AddBrand.js        # Add brand form
```

## 🐛 Troubleshooting

### BLIP Model Loading Issues
If you get memory errors:
```python
# In backend/services/image_captioning.py, use smaller model:
self.processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-base")
self.model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-base")
```

### CORS Errors
Make sure Flask-CORS is installed and backend is running on port 5000.

### OpenAI API Errors
- Verify API key in `.env`
- Check API quota/billing
- Use fallback: System returns base caption if GPT fails

### ChromaDB Errors
Delete and recreate the database:
```bash
rm -rf backend/chroma_db
```

## 🔄 Model Alternatives

### Image Captioning
- **Current**: BLIP (base) - Fast, 400MB
- **Better**: BLIP-2 (FlanT5-XXL) - More accurate, 15GB
- **Alternative**: LLaVA - Multimodal understanding

### LLM
- **Current**: GPT-3.5-turbo - Cost-effective
- **Better**: GPT-4 - Higher quality
- **Alternative**: Claude Sonnet, Fine-tuned LLaMA-3

### Embeddings
- **Current**: all-MiniLM-L6-v2 - Fast, lightweight
- **Better**: OpenAI text-embedding-3-large - Higher quality

## 📊 Performance

- **Brand Onboarding**: 30-60 seconds
- **Caption Generation**: 8-15 seconds
- **Image Processing**: 2-3 seconds
- **RAG Retrieval**: <1 second

## 🚧 Future Improvements

1. **Add BLIP-2** for better image understanding
2. **Implement batch processing** for multiple images
3. **Add A/B testing** for caption variants
4. **Implement caching** for faster responses
5. **Add user authentication** for multi-user support
6. **Deploy to cloud** (AWS/GCP)
7. **Add analytics dashboard** for caption performance




## 🙏 Acknowledgments

- Salesforce for BLIP models
- Google for Gemini API
- ChromaDB for vector database
